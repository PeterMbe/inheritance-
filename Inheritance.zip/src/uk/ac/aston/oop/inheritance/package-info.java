/**
 * Main package of the inheritance lab program.
 * 
 * @author Peter
 * @version 1.0
 */

package uk.ac.aston.oop.inheritance;

