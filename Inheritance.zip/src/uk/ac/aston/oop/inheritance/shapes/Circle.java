
package uk.ac.aston.oop.inheritance.shapes;

//import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;

/**
 * Circle, specified as center + radius
 */
public class Circle extends Ellipse{

	//private double centerX, centerY;
	//private double radius;
/**
 * 
 * @param cirX this is the X coordinate of the circle 
 * @param cirY this is the Y coordinate of the circle
 * @param radius this is the Radius coordinate of the circle
 */
	public Circle(double cirX, double cirY, double radius) {
		//this.centerX = centerX;
		//this.centerY = centerY;
		//this.radius = radius;
		super(cirX - radius,cirY - radius,radius * 2,radius * 2);
	}

	//public double getX() { return centerX; }
	//public double getY() { return centerY; }
	//public double getWidth()  { return radius * 2; }
	//public double getHeight() { return radius * 2; }

	//public void draw(GraphicsContextWrapper gc) {
		//gc.oval(cirX - radius, centerY - radius, radius * 2, radius * 2);
	//}
	/**
	 * this returns the radius of the circle.
	 * @return getWidth() /2 which is the radius of the circle.
	 */
	public double getRadius() { return getWidth()/2; }
	
}
