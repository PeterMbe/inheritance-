

package uk.ac.aston.oop.inheritance.shapes;

import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;
/**
 * Ellipse is specified with the upper left corner and the width and height 
 */
public class Ellipse extends Shape {
/**
 * 
 * @param ulX X coordinate of upper left corner ellipse.
 * @param ulY Y coordinate of upper left corner ellipse.
 * @param w width of ellipse.
 * @param h height of ellipse.
 */
	//private double upperLeftX, upperLeftY;
	//private double width, height;

	public Ellipse(double upperLeftX, double upperLeftY, double width, double height) {
		//this.upperLeftX = upperLeftX;
		//this.upperLeftY = upperLeftY;
		//this.width = width;
		//this.height = height;
		super(upperLeftX,upperLeftY,width,height);
	}

	//public double getX() { return upperLeftX; }
	//public double getY() { return upperLeftY; }
	//public double getWidth()  { return width; }
	//public double getHeight() { return height; }
	/**
	 * this gets the x coordinate the Y coordinate the with and the height from the shape which comes from the launcher
	 */

	@Override public void draw(GraphicsContextWrapper gc) {
		gc.oval(getX(), getY(), getWidth(), getHeight());
	}
	
}
