
package uk.ac.aston.oop.inheritance.shapes;

import javafx.scene.paint.Color;
import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;
/** 
 * Filled rectangle is specified by the fill color and the upper left corner and width and height.
 */
public class FilledRectangle extends Rectangle {
	
	private Color fill;
	
	/**
	 * 
	 * @param fill is the fill color of the rectangle.
	 * @param ulX X coordinate of upper left corner of the rectangle .
	 * @param ulY Y coordinate of upper left corner of the rectangle.
	 * @param w width of rectangle.
	 * @param h height of rectangle.
	 */
	
	public FilledRectangle(Color fill,double ulX,double ulY,double width, double height) {
		super(ulX,ulY,width,height);
		this.fill = fill;
		}
	/**
	 * 
	 * @return this returns the fill color.
	 */
	public Color getFill() {return fill;}
	
	/**
	 * this will get the gill colour, the x,y coodinates, width and the height.
	 */
	
	@Override public void draw(GraphicsContextWrapper gc) {
		super.draw(gc);
		gc.fill(fill);
		gc.fillRect(getX(), getY(), getWidth(), getHeight());
	}
}
