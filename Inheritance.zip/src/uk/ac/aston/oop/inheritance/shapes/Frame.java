
package uk.ac.aston.oop.inheritance.shapes;

import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;

/**
 * Frame creates an inner and outer rectangle and needs x coord, y cood, height, width and the frame thickness
 */

public class Frame extends Shape{
	/**
	 * the outer and inner are both protected values which are accesssible from subclasses
	 */
	protected Rectangle outerRectangle;
	protected Rectangle innerRectangle;
	private static final int FRAME_THICKNESS = 10;
	
	/**
	 * creates a new instance.
	 * 
	 * @param ulX X coordinate of upper left corner.
	 * @param ulY Y coordinate of upper left corner.
	 * @param w width of rectangle .
	 * @param h height of rectangle.
	 * 
	 */
	public Frame(double ulX,double ulY,double width,double height) {
		super(ulX,ulY,width,height);
		this.outerRectangle = new Rectangle(ulX,ulY,width,height);
		this.innerRectangle = new Rectangle(ulX + FRAME_THICKNESS, ulY + FRAME_THICKNESS ,width - FRAME_THICKNESS * 2,height - FRAME_THICKNESS * 2);
	}
	/**
	 * this draws the outer and inner rectangles.
	 */

	@Override public void draw(GraphicsContextWrapper gc) {
		outerRectangle.draw(gc);
		innerRectangle.draw(gc);
	}

}
