

package uk.ac.aston.oop.inheritance.shapes;

import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;

/**
 * rectangle is specified with the upper left corner and the width an height
 */
public class Rectangle extends Shape {

	//private double upperLeftX, upperLeftY;
	//private double width, height;
	/**
	 * 
	 * @param ulX X coordinate of upper left corner of the rectangle .
	 * @param ulY Y coordinate of upper left corner of the rectangle.
	 * @param w width of rectangle.
	 * @param h height of rectangle.
	 */

	public Rectangle(double ulX, double ulY, double width, double height) {
		//this.upperLeftX = ulX;
		//this.upperLeftY = ulY;
		//this.width  = width;
		//this.height = height;
		super(ulX,ulY,width,height);
	}

	//public double getX() { return upperLeftX; }
	//public double getY() { return upperLeftY; }
	//public double getWidth()  { return width;  }
	//public double getHeight() { return height; }

	/**
	 * this gets the x, y, width and the height for the rectangle.
	 */
	@Override public void draw(GraphicsContextWrapper gc) {
		gc.lineWidth(5);
		gc.rect(getX(), getY(), getWidth(), getHeight());
	}

}
