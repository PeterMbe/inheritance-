
package uk.ac.aston.oop.inheritance.shapes;
import uk.ac.aston.oop.inheritance.util.GraphicsContextWrapper;

/**
 * shape is specified upper left corner + width and height 
 */

public class Shape {
	/**
	 * creates a new instance.
	 * 
	 * @param ulX X coordinate of upper left corner.
	 * @param ulY Y coordinate of upper left corner.
	 * @param w width of shape.
	 * @param h height of shape.
	 */
	private double upperLeftX,	upperLeftY, width, height ;
	/**
	 * 
	 * @param ulX X coordinate of upper left corner.
	 * @param ulY Y coordinate of upper left corner.
	 * @param w width of shape.
	 * @param h height of shape.
	 */
	
	public Shape(double ulX, double ulY, double w, double h) {
		this.upperLeftX = ulX; this.upperLeftY = ulY;
		this.width = w; this.height = h;
	}
	/**
	 * returns the X coordinate of the upper left corner.
	 * 
	 * @return X coordinate of the upper left corner.
	 */
	
	public double getX() {return upperLeftX;}
	/**
	 * returns the Y coordinate of the upper left corner.
	 * 
	 * @return Y coordinate of the upper left corner.
	 */
	public double getY() {return upperLeftY;}
	/**
	 * returns the Width coordinate of the upper left corner.
	 * 
	 * @return Width coordinate of the upper left corner.
	 */
	public double getWidth() {return width;}
	/**
	 * returns the Height coordinate of the upper left corner.
	 * 
	 * @return Height coordinate of the upper left corner.
	 */
	public double getHeight() {return height;}
	
	/**
	 * 
	 * @param gc this method prints outs that the shape cannot be drawn
	 */
	 
	public void draw(GraphicsContextWrapper gc) {
		System.out.println("cannot draw shape");
	}
	
}
